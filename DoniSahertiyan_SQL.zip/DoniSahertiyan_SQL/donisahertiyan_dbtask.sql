-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2024 at 11:39 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `donisahertiyan_dbtask`
--

-- --------------------------------------------------------

--
-- Table structure for table `table_order`
--

CREATE TABLE `table_order` (
  `TableOrderId` int(11) NOT NULL,
  `TableId` varchar(36) NOT NULL,
  `MenuName` varchar(75) NOT NULL,
  `QuantityOrder` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `table_order`
--

INSERT INTO `table_order` (`TableOrderId`, `TableId`, `MenuName`, `QuantityOrder`) VALUES
(2108202401, '74d81071-5f80-11ef-b9cd-088fc32a6757', 'Ayam Goreng Krispi', 3),
(2108202402, 'cdbb0bd4-5f80-11ef-b9cd-088fc32a6757', 'Nasi Goreng Lada Hitam', 2),
(2108202403, 'fd2a3ade-5f80-11ef-b9cd-088fc32a6757', 'Sushi', 4),
(2108202404, '17a81017-5f81-11ef-b9cd-088fc32a6757', 'Ayam Bulgogi', 5);

-- --------------------------------------------------------

--
-- Table structure for table `table_specification`
--

CREATE TABLE `table_specification` (
  `TableId` varchar(36) NOT NULL,
  `TableNumber` int(11) DEFAULT NULL,
  `ChairNumber` int(11) DEFAULT NULL,
  `TablePic` varchar(75) NOT NULL,
  `TableType` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `table_specification`
--

INSERT INTO `table_specification` (`TableId`, `TableNumber`, `ChairNumber`, `TablePic`, `TableType`) VALUES
('17a81017-5f81-11ef-b9cd-088fc32a6757', 13, 4, 'Tema Korea', 'Luxury'),
('74d81071-5f80-11ef-b9cd-088fc32a6757', 19, 1, 'Tema Kerajaan', 'Luxury'),
('cdbb0bd4-5f80-11ef-b9cd-088fc32a6757', 20, 2, 'Tema Minimalis', 'Imperior'),
('fd2a3ade-5f80-11ef-b9cd-088fc32a6757', 16, 3, 'Tema Jepang', 'Standard');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `table_order`
--
ALTER TABLE `table_order`
  ADD PRIMARY KEY (`TableOrderId`),
  ADD KEY `TableId` (`TableId`);

--
-- Indexes for table `table_specification`
--
ALTER TABLE `table_specification`
  ADD PRIMARY KEY (`TableId`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `table_order`
--
ALTER TABLE `table_order`
  ADD CONSTRAINT `table_order_ibfk_1` FOREIGN KEY (`TableId`) REFERENCES `table_specification` (`TableId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
